#include <stdio.h>
#define na [
#define naa ]
#define naaa =
#define thde <
#define naaaa }
#define naaaaa ;
#define ten 0x2a
#define one 0x07
#define six 0x3e
#define two 0x0c
#define hamtdaa {
#define chamtai (
#define five 0x12
#define nine 0x36
#define four 0x1d
#define taaltsay *
#define naaaaaaa 0
#define seven 0x01
#define three 0x1a
#define eight 0x10
#define baihad int
#define hailtsay )
#define chamtaii ++
#define naaaaaa for
#define twelve 0x3a
#define eleven 0x58
#define hairaa flag
#define chuluu char
#define sixteen 0x56
#define fifteen 0x5d
#define naaaaaaaa ^=
#define fourteen 0x0e
#define hoyulaa const
#define eighteen 0x14
#define thirteen 0x59
#define hairaaaa main
#define baihdaa static
#define seventeen 0x48
#define hairaaa sizeof
#define huurhun return
#define fake_flag "%s"
#define naaaaaaaaa 0x69
#define hairlayy printf
#define wantutrifofayw "1 2 3 4 5\n"
#define nananananaana "na na na na naa na\n"
#define nanananananaana "na na na na na naa na\n"

hoyulaa chuluu taaltsay hairaa chamtai hailtsay hamtdaa baihdaa chuluu hairaa na naa naaa hamtdaa one, two, three, four, five, six, seven, eight, nine, ten, nine, eleven, three, nine, twelve, thirteen, nine, fourteen, fifteen, eight, eight, sixteen, seventeen, eighteen naaaa naaaaa naaaaaa chamtai baihad bolno naaa naaaaaaa naaaaa bolno thde hairaaa chamtai hairaa hailtsay naaaaa bolno chamtaii hailtsay hamtdaa hairaa na bolno naa naaaaaaaa naaaaaaaaa naaaaa naaaa huurhun hairaa naaaaa naaaa
baihad hairaaaa chamtai hailtsay hamtdaa hairlayy chamtai nananananaana hailtsay naaaaa hairlayy chamtai nanananananaana hailtsay naaaaa hairlayy chamtai nananananaana hailtsay naaaaa hairlayy chamtai wantutrifofayw hailtsay naaaaa hairlayy chamtai fake_flag, hairaa chamtai hailtsay hailtsay naaaaa huurhun naaaaaaa naaaaa naaaa