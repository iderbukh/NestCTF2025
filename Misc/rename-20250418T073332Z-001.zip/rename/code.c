#include <stdio.h>

const char *flag() {
    static char flag[] = {0x07, 0x0c, 0x1a, 0x1d, 0x12, 0x3e, 0x01, 0x10, 0x36, 0x2a, 0x36, 0x58, 0x1a, 0x36, 0x3a, 0x59, 0x36, 0x0e, 0x5d, 0x10, 0x10, 0x56, 0x48, 0x14};
    for (int i = 0; i < sizeof(flag); i++) {
        flag[i] ^= 0x69;
    }
    return flag;
}

int main() {
    const char *f = flag();
    printf("na na na na naa na\n");
    printf("na na na na na naa na\n");
    printf("na na na na naa na\n");
    printf("1 2 3 4 5\n");
    printf("%s", f);
    return 0;
}
