# MathGramming

### Build the Docker image
`docker build -t mathgramming .`

### Run the challenge
`docker run -itd --rm -p 10001:10001 mathgramming`


# Writeup
Calculate logarithm base and exp

x^3 = 8

Find base

`x = 8 ** (1 / 3)`

2^x = 8

Find exp

`x = math.log(8, 2)`

### Flag
nest{L0g4r1thm_IN_Pr0gr4mming!!}
