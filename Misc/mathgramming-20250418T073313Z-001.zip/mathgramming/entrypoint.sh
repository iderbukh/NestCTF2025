#!/bin/sh
socat TCP-LISTEN:10001,reuseaddr,fork EXEC:"python3 /app/challenge.py"