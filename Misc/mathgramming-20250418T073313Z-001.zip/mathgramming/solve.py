from pwn import *
import math

rem = remote('localhost', 10001)

flag = ''
while True:
    rem.recvuntil(b'Solve: ')
    question = rem.recvline().strip().decode()
    print(question)
    if question[0] == 'x':
        # FIND BASE
        exp = int(question.split('^')[1].split(' = ')[0])
        result = int(question.split(' = ')[1])
        x = result ** (1 / exp)
        rem.sendlineafter(b'x = ', str(round(x)).encode())
    else:
        # FIND EXP
        base = int(question.split('^')[0])
        result = int(question.split(' = ')[1])
        exp = math.log(result, base)
        rem.sendlineafter(b'x = ', str(int(exp)).encode())

    res = rem.recvline().strip().decode()
    if 'Correct!' in res:
        flag += res[-1]
        if res[-1] == '}':
            print(flag)
            rem.close()
            break
