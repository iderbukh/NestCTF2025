import random

FLAG = "nest{L0g4r1thm_IN_Pr0gr4mming!!}"
round = 0

def generate_exp_question():
    base = random.randint(2, 20)
    x = random.randint(1, 6)
    result = base ** x
    return f"Solve: {base}^x = {result}", x

def generate_root_question():
    x = random.randint(1, 20)
    exp = random.randint(1, 6)
    result = x ** exp
    return f"Solve: x^{exp} = {result}", x

print("Let's calculate some logarithms!")

while True:
    if round == len(FLAG):
        print("🎉 You've revealed the entire flag!")
        break

    question_type = random.choice(["exp", "root"])

    if question_type == "exp":
        question, answer = generate_exp_question()
    else:
        question, answer = generate_root_question()

    print(f"\n{question}")
    try:
        user_input = input("x = ")
        x = int(user_input)
        if x == answer:
            print("Correct! Here is your flag piece:", FLAG[round])
            round += 1
        else:
            print("Incorrect. Bye.")
            break
    except:
        print("Invalid input. Bye.")
        break
