from Crypto.Util.number import *

from mt19937predictor import MT19937Predictor
predictor = MT19937Predictor() #https://github.com/kmyk/mersenne-twister-predictor
enc = 3272444778782094099214891778203265486996913542060675887929360719149172608085432071
with open("useful.txt", "r") as f:
    keys = [int(line.strip()) for line in f]
#getRandombits() = mersenne twister 
#https://book.jorianwoltjer.com/cryptography/pseudo-random-number-generators-prng
for key in keys:
    for i in range(8):
        part = (key >> (32 * i)) & 0xFFFFFFFF
        predictor.setrandbits(part, 32)
pre_key = predictor.getrandbits(256)
print(long_to_bytes(enc ^ pre_key))