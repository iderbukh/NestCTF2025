from Crypto.Util.number import long_to_bytes as l2b , bytes_to_long as b2l
import random
flag = b"nest{****************************}"
key = [random.getrandbits(256) for _ in range(79)]
enc = b2l(flag) ^ key[78]
print(enc)
with open("useful.txt", "w") as f:
    for i, k in enumerate(key[0:78]):
        f.write(f"{k}\n")
